#ifndef _CONSOLE_H_
#define _CONSOLE_H_

typedef void (*CmdFunc)(void);

#endif