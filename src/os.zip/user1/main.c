#include "lib.h"

int main(void)
{
    while (1) {
        waitu();
    }
    return 0;
}